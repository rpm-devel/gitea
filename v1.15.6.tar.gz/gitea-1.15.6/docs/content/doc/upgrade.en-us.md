---
date: "2016-12-01T16:00:00+02:00"
title: "Upgrade"
slug: "upgrade"
weight: 10
toc: false
draft: false
menu:
  sidebar:
    name: "Upgrade"
    weight: 20
    identifier: "upgrade"
---
